import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { BookOpen, Sparkles, TrendingUp, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import type { JournalEntry, InsertJournalEntry } from "@shared/schema";

export default function Journal() {
  const { toast } = useToast();
  const [todayContent, setTodayContent] = useState("");

  const { data: entries = [], isLoading } = useQuery<JournalEntry[]>({
    queryKey: ["/api/journal"],
  });

  const createMutation = useMutation({
    mutationFn: async (entry: InsertJournalEntry) => {
      return await apiRequest("POST", "/api/journal", entry);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal"] });
      setTodayContent("");
      toast({
        title: "Journal saved!",
        description: "Your learning has been recorded with AI feedback.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!todayContent.trim()) {
      toast({
        title: "Error",
        description: "Please write about what you learned today",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate({ content: todayContent });
  };

  const latestEntry = entries[0];
  const averageCompletion =
    entries.length > 0
      ? Math.round(
          entries.reduce((sum, e) => sum + e.completionPercentage, 0) / entries.length
        )
      : 0;

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
          Daily Learning Journal
        </h1>
        <p className="text-muted-foreground mt-1">
          Reflect on your learning and get AI-powered insights
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 border-2 border-chart-1/20 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-chart-1" />
              Today's Learning
            </CardTitle>
            <CardDescription>What did you learn or work on today?</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                value={todayContent}
                onChange={(e) => setTodayContent(e.target.value)}
                placeholder="Write about what you learned today, challenges you faced, concepts you understood, projects you worked on..."
                rows={8}
                className="resize-none"
                data-testid="input-journal-content"
              />
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="w-full bg-gradient-to-r from-chart-1 to-chart-2 hover:opacity-90"
                data-testid="button-save-journal"
              >
                {createMutation.isPending ? "Analyzing..." : "Save & Get AI Feedback"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="border-2 border-chart-2/20">
            <CardHeader>
              <CardTitle className="text-lg">Today's Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center">
                <div className="relative w-32 h-32">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="8"
                      className="text-muted/20"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="40"
                      fill="none"
                      stroke="url(#journal-gradient)"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={`${(latestEntry?.completionPercentage || 0) * 2.51} 251`}
                      className="transition-all duration-1000"
                    />
                    <defs>
                      <linearGradient id="journal-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" className="text-chart-1" stopColor="currentColor" />
                        <stop offset="50%" className="text-chart-2" stopColor="currentColor" />
                        <stop offset="100%" className="text-chart-3" stopColor="currentColor" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <div className="text-2xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
                      {latestEntry?.completionPercentage || 0}%
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-2 border-chart-3/20">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Average
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-3xl font-bold bg-gradient-to-r from-chart-2 to-chart-3 bg-clip-text text-transparent">
                  {averageCompletion}%
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Across {entries.length} {entries.length === 1 ? "entry" : "entries"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {latestEntry?.feedback && (
        <Card className="border-2 border-chart-1/20 bg-gradient-to-br from-chart-1/5 via-chart-2/5 to-chart-3/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-chart-1" />
              AI Feedback
            </CardTitle>
            <CardDescription>Personalized insights on your learning</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed whitespace-pre-wrap" data-testid="text-journal-feedback">
              {latestEntry.feedback}
            </p>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-1/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-24 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : entries.length > 1 ? (
        <Card>
          <CardHeader>
            <CardTitle>Journal History</CardTitle>
            <CardDescription>Your learning journey over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {entries.slice(1, 10).map((entry) => (
                <div
                  key={entry.id}
                  className="p-4 rounded-lg border bg-card hover-elevate transition-all"
                  data-testid={`entry-${entry.id}`}
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {format(new Date(entry.date), "PPP")}
                    </div>
                    <div className="text-xl font-bold bg-gradient-to-r from-chart-1 to-chart-2 bg-clip-text text-transparent">
                      {entry.completionPercentage}%
                    </div>
                  </div>
                  <p className="text-sm line-clamp-2 mb-2">{entry.content}</p>
                  {entry.feedback && (
                    <div className="mt-3 p-3 rounded-lg bg-muted/50 border-l-2 border-chart-1">
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {entry.feedback}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : entries.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <BookOpen className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No journal entries yet</h3>
            <p className="text-muted-foreground text-center">
              Start documenting your learning journey today
            </p>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
