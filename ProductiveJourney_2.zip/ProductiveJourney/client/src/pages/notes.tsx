import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Plus, X, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { StickyNote, InsertStickyNote } from "@shared/schema";

const NOTE_COLORS = [
  { name: "purple", gradient: "from-purple-400 to-pink-400" },
  { name: "blue", gradient: "from-blue-400 to-cyan-400" },
  { name: "green", gradient: "from-green-400 to-emerald-400" },
  { name: "yellow", gradient: "from-yellow-400 to-orange-400" },
  { name: "pink", gradient: "from-pink-400 to-rose-400" },
];

export default function Notes() {
  const { toast } = useToast();
  const [newNoteContent, setNewNoteContent] = useState("");
  const [selectedColor, setSelectedColor] = useState("purple");
  const [draggedNote, setDraggedNote] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });

  const { data: notes = [], isLoading } = useQuery<StickyNote[]>({
    queryKey: ["/api/notes"],
  });

  const createMutation = useMutation({
    mutationFn: async (note: InsertStickyNote) => {
      return await apiRequest("POST", "/api/notes", note);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      setNewNoteContent("");
      toast({
        title: "Note created!",
        description: "Your sticky note has been added.",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: Partial<StickyNote> & { id: string }) => {
      return await apiRequest("PATCH", `/api/notes/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
      toast({
        title: "Note deleted",
        description: "Your sticky note has been removed.",
      });
    },
  });

  const handleCreateNote = () => {
    if (!newNoteContent.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for the note",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate({
      content: newNoteContent,
      x: Math.random() * 300 + 100,
      y: Math.random() * 300 + 100,
      color: selectedColor,
    });
  };

  const handleMouseDown = (e: React.MouseEvent, noteId: string, noteX: number, noteY: number) => {
    setDraggedNote(noteId);
    setDragOffset({
      x: e.clientX - noteX,
      y: e.clientY - noteY,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (draggedNote) {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;
      updateMutation.mutate({ id: draggedNote, x: newX, y: newY });
    }
  };

  const handleMouseUp = () => {
    setDraggedNote(null);
  };

  return (
    <div className="container max-w-7xl mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
          Sticky Notes
        </h1>
        <p className="text-muted-foreground mt-1">Create and organize notes anywhere on the canvas</p>
      </div>

      <Card className="border-2 border-chart-1/20 shadow-lg">
        <CardContent className="p-6 space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">New Note</label>
            <Textarea
              value={newNoteContent}
              onChange={(e) => setNewNoteContent(e.target.value)}
              placeholder="Write your note here..."
              rows={3}
              className="resize-none"
              data-testid="input-note-content"
            />
          </div>
          <div className="flex items-center gap-4">
            <label className="text-sm font-medium">Color:</label>
            <div className="flex gap-2">
              {NOTE_COLORS.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color.name)}
                  className={`w-10 h-10 rounded-lg bg-gradient-to-br ${color.gradient} hover:scale-110 transition-transform ${
                    selectedColor === color.name ? "ring-2 ring-offset-2 ring-primary" : ""
                  }`}
                  data-testid={`button-color-${color.name}`}
                  aria-label={`Select ${color.name} color`}
                />
              ))}
            </div>
          </div>
          <Button
            onClick={handleCreateNote}
            disabled={createMutation.isPending}
            className="w-full bg-gradient-to-r from-chart-1 to-chart-2"
            data-testid="button-create-note"
          >
            <Plus className="w-4 h-4 mr-2" />
            {createMutation.isPending ? "Creating..." : "Create Sticky Note"}
          </Button>
        </CardContent>
      </Card>

      <div
        className="relative min-h-[600px] bg-gradient-to-br from-background via-muted/20 to-background rounded-lg border-2 border-dashed border-muted-foreground/20 p-4"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        data-testid="canvas-notes"
      >
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-muted-foreground">Loading notes...</div>
          </div>
        ) : notes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="text-6xl mb-4">📝</div>
            <h3 className="text-lg font-semibold mb-2">No sticky notes yet</h3>
            <p className="text-muted-foreground">Create your first note to get started!</p>
          </div>
        ) : (
          notes.map((note) => {
            const colorGradient = NOTE_COLORS.find((c) => c.name === note.color)?.gradient || NOTE_COLORS[0].gradient;
            return (
              <div
                key={note.id}
                className={`absolute w-64 shadow-2xl rounded-lg cursor-move ${
                  draggedNote === note.id ? "z-50 scale-105" : "z-10"
                } transition-transform`}
                style={{ left: `${note.x}px`, top: `${note.y}px` }}
                onMouseDown={(e) => handleMouseDown(e, note.id, note.x, note.y)}
                data-testid={`note-${note.id}`}
              >
                <div className={`bg-gradient-to-br ${colorGradient} p-4 rounded-lg`}>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <GripVertical className="w-5 h-5 text-white/70 flex-shrink-0" />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteMutation.mutate(note.id);
                      }}
                      className="h-6 w-6 text-white/70 hover:text-white hover:bg-white/20"
                      data-testid={`button-delete-note-${note.id}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="text-white whitespace-pre-wrap break-words min-h-[80px]">
                    {note.content}
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
