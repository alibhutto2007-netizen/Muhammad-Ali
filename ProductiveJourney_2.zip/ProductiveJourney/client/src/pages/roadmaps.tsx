import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Map, Check, Trash2, Target } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import type { Roadmap, InsertRoadmap } from "@shared/schema";

export default function Roadmaps() {
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  const [newRoadmap, setNewRoadmap] = useState<InsertRoadmap>({
    title: "",
    description: "",
    completed: false,
  });

  const { data: roadmaps = [], isLoading } = useQuery<Roadmap[]>({
    queryKey: ["/api/roadmaps"],
  });

  const createMutation = useMutation({
    mutationFn: async (roadmap: InsertRoadmap) => {
      return await apiRequest("POST", "/api/roadmaps", roadmap);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roadmaps"] });
      setIsAdding(false);
      setNewRoadmap({ title: "", description: "", completed: false });
      toast({
        title: "Roadmap created!",
        description: "Your roadmap has been added.",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return await apiRequest("PATCH", `/api/roadmaps/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roadmaps"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/roadmaps/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/roadmaps"] });
      toast({
        title: "Roadmap deleted",
        description: "The roadmap has been removed.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoadmap.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a roadmap title",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newRoadmap);
  };

  const activeRoadmaps = roadmaps.filter((r) => !r.completed);
  const completedRoadmaps = roadmaps.filter((r) => r.completed);

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
            Roadmaps
          </h1>
          <p className="text-muted-foreground mt-1">Plan your learning journey and track progress</p>
        </div>
        <Button
          onClick={() => setIsAdding(true)}
          size="default"
          className="bg-gradient-to-r from-chart-1 to-chart-2 hover:opacity-90 transition-opacity"
          data-testid="button-add-roadmap"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Roadmap
        </Button>
      </div>

      {isAdding && (
        <Card className="border-2 border-chart-1/20 shadow-lg">
          <CardHeader>
            <CardTitle>Create New Roadmap</CardTitle>
            <CardDescription>Define your learning path</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Roadmap Title *</Label>
                <Input
                  id="title"
                  value={newRoadmap.title}
                  onChange={(e) => setNewRoadmap({ ...newRoadmap, title: e.target.value })}
                  placeholder="e.g., Full Stack Development"
                  data-testid="input-roadmap-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newRoadmap.description || ""}
                  onChange={(e) => setNewRoadmap({ ...newRoadmap, description: e.target.value })}
                  placeholder="What will you learn on this journey?"
                  className="resize-none"
                  rows={4}
                  data-testid="input-roadmap-description"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAdding(false)}
                  data-testid="button-cancel-roadmap"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-gradient-to-r from-chart-1 to-chart-2"
                  data-testid="button-submit-roadmap"
                >
                  {createMutation.isPending ? "Creating..." : "Create Roadmap"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-5 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : roadmaps.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Map className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No roadmaps yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create your first roadmap to start planning your learning journey
            </p>
            <Button
              onClick={() => setIsAdding(true)}
              variant="outline"
              data-testid="button-create-first-roadmap"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Roadmap
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {activeRoadmaps.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-chart-1" />
                In Progress ({activeRoadmaps.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeRoadmaps.map((roadmap) => (
                  <Card
                    key={roadmap.id}
                    className="hover-elevate transition-all duration-300 border-l-4 border-l-chart-1"
                    data-testid={`card-roadmap-${roadmap.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{roadmap.title}</CardTitle>
                          {roadmap.description && (
                            <CardDescription className="mt-2">
                              {roadmap.description}
                            </CardDescription>
                          )}
                        </div>
                        <Checkbox
                          checked={roadmap.completed}
                          onCheckedChange={(checked) =>
                            toggleMutation.mutate({ id: roadmap.id, completed: !!checked })
                          }
                          className="mt-1"
                          data-testid={`checkbox-roadmap-${roadmap.id}`}
                        />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-muted-foreground">
                        Created {format(new Date(roadmap.createdAt), "PPP")}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate(roadmap.id)}
                        className="w-full text-destructive hover:text-destructive"
                        data-testid={`button-delete-roadmap-${roadmap.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {completedRoadmaps.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Check className="w-5 h-5 text-chart-4" />
                Completed ({completedRoadmaps.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {completedRoadmaps.map((roadmap) => (
                  <Card
                    key={roadmap.id}
                    className="opacity-75 hover:opacity-100 transition-opacity border-l-4 border-l-chart-4"
                    data-testid={`card-completed-roadmap-${roadmap.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <CardTitle className="text-lg line-through">
                            {roadmap.title}
                          </CardTitle>
                        </div>
                        <Checkbox
                          checked={roadmap.completed}
                          onCheckedChange={(checked) =>
                            toggleMutation.mutate({ id: roadmap.id, completed: !!checked })
                          }
                          className="mt-1"
                          data-testid={`checkbox-completed-roadmap-${roadmap.id}`}
                        />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate(roadmap.id)}
                        className="w-full text-destructive hover:text-destructive"
                        data-testid={`button-delete-completed-roadmap-${roadmap.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
