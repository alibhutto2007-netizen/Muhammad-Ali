import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Moon, TrendingUp, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import type { SleepRecord, InsertSleepRecord } from "@shared/schema";

export default function Sleep() {
  const { toast } = useToast();
  const [hoursSlept, setHoursSlept] = useState(8);

  const { data: sleepRecords = [], isLoading } = useQuery<SleepRecord[]>({
    queryKey: ["/api/sleep"],
  });

  const createMutation = useMutation({
    mutationFn: async (record: InsertSleepRecord) => {
      return await apiRequest("POST", "/api/sleep", record);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sleep"] });
      toast({
        title: "Sleep logged!",
        description: "Your sleep data has been saved with AI feedback.",
      });
      setHoursSlept(8);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (hoursSlept < 0 || hoursSlept > 24) {
      toast({
        title: "Invalid input",
        description: "Please enter hours between 0 and 24",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate({ hoursSlept });
  };

  const latestRecord = sleepRecords[0];
  const averageSleep =
    sleepRecords.length > 0
      ? Math.round(
          sleepRecords.reduce((sum, r) => sum + r.hoursSlept, 0) / sleepRecords.length
        )
      : 0;

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
          Sleep Cycle Tracker
        </h1>
        <p className="text-muted-foreground mt-1">Monitor your sleep and get AI-powered insights</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-2 border-chart-2/20 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Moon className="w-5 h-5 text-chart-2" />
              Log Your Sleep
            </CardTitle>
            <CardDescription>How many hours did you sleep?</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-end gap-4">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="hours">Hours Slept</Label>
                    <Input
                      id="hours"
                      type="number"
                      min="0"
                      max="24"
                      step="0.5"
                      value={hoursSlept}
                      onChange={(e) => setHoursSlept(parseFloat(e.target.value))}
                      className="text-2xl font-bold h-16"
                      data-testid="input-hours-slept"
                    />
                  </div>
                  <div className="text-center pb-4">
                    <div className="text-4xl font-bold bg-gradient-to-r from-chart-2 to-chart-3 bg-clip-text text-transparent">
                      {hoursSlept}
                    </div>
                    <div className="text-sm text-muted-foreground">hours</div>
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="24"
                  step="0.5"
                  value={hoursSlept}
                  onChange={(e) => setHoursSlept(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 rounded-lg appearance-none cursor-pointer"
                  data-testid="slider-hours"
                />
              </div>
              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="w-full bg-gradient-to-r from-chart-2 to-chart-3 hover:opacity-90"
                data-testid="button-log-sleep"
              >
                {createMutation.isPending ? "Analyzing..." : "Log Sleep & Get Feedback"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border-2 border-chart-1/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-chart-1" />
              Sleep Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-center">
              <div className="relative w-48 h-48">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="8"
                    className="text-muted/20"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="url(#gradient)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${(latestRecord?.sleepPercentage || 0) * 2.51} 251`}
                    className="transition-all duration-1000"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" className="text-chart-1" stopColor="currentColor" />
                      <stop offset="50%" className="text-chart-2" stopColor="currentColor" />
                      <stop offset="100%" className="text-chart-3" stopColor="currentColor" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="text-4xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
                    {latestRecord?.sleepPercentage || 0}%
                  </div>
                  <div className="text-sm text-muted-foreground">Sleep Quality</div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-lg bg-muted/50">
                <div className="text-2xl font-bold">{latestRecord?.hoursSlept || 0}h</div>
                <div className="text-sm text-muted-foreground">Last Night</div>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted/50">
                <div className="text-2xl font-bold">{averageSleep}h</div>
                <div className="text-sm text-muted-foreground">Average</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {latestRecord?.feedback && (
        <Card className="border-2 border-chart-1/20 bg-gradient-to-br from-chart-1/5 via-chart-2/5 to-chart-3/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-chart-1" />
              AI Feedback
            </CardTitle>
            <CardDescription>Personalized insights about your sleep</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed" data-testid="text-sleep-feedback">
              {latestRecord.feedback}
            </p>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-muted rounded w-1/4"></div>
              </CardHeader>
              <CardContent>
                <div className="h-20 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : sleepRecords.length > 1 ? (
        <Card>
          <CardHeader>
            <CardTitle>Sleep History</CardTitle>
            <CardDescription>Your recent sleep records</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sleepRecords.slice(1, 8).map((record) => (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover-elevate transition-all"
                  data-testid={`record-${record.id}`}
                >
                  <div className="flex items-center gap-4">
                    <Moon className="w-5 h-5 text-chart-2" />
                    <div>
                      <div className="font-semibold">{record.hoursSlept} hours</div>
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(record.date), "PPP")}
                      </div>
                    </div>
                  </div>
                  <div className="text-2xl font-bold bg-gradient-to-r from-chart-1 to-chart-2 bg-clip-text text-transparent">
                    {record.sleepPercentage}%
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
