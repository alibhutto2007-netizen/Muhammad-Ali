import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Bell, Check, Trash2, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import type { Task, InsertTask } from "@shared/schema";

export default function Tasks() {
  const { toast } = useToast();
  const [isAdding, setIsAdding] = useState(false);
  
  // Set default due time to tomorrow at noon
  const getDefaultDueTime = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(12, 0, 0, 0);
    return tomorrow;
  };
  
  const [newTask, setNewTask] = useState<InsertTask>({
    title: "",
    description: "",
    dueTime: getDefaultDueTime(),
    completed: false,
  });

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const createMutation = useMutation({
    mutationFn: async (task: InsertTask) => {
      return await apiRequest("POST", "/api/tasks", task);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setIsAdding(false);
      setNewTask({ title: "", description: "", dueTime: getDefaultDueTime(), completed: false });
      toast({
        title: "Task created!",
        description: "Your reminder has been set.",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return await apiRequest("PATCH", `/api/tasks/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({
        title: "Task deleted",
        description: "The task has been removed.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a task title",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate(newTask);
  };

  const sortedTasks = [...tasks].sort((a, b) => 
    new Date(a.dueTime).getTime() - new Date(b.dueTime).getTime()
  );

  const incompleteTasks = sortedTasks.filter(t => !t.completed);
  const completedTasks = sortedTasks.filter(t => t.completed);

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
            Task Reminders
          </h1>
          <p className="text-muted-foreground mt-1">Never miss an important task again</p>
        </div>
        <Button
          onClick={() => setIsAdding(true)}
          size="default"
          className="bg-gradient-to-r from-chart-1 to-chart-2 hover:opacity-90 transition-opacity"
          data-testid="button-add-task"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Task
        </Button>
      </div>

      {isAdding && (
        <Card className="border-2 border-chart-1/20 shadow-lg">
          <CardHeader>
            <CardTitle>Create New Task</CardTitle>
            <CardDescription>Set a reminder for your task</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Task Title *</Label>
                <Input
                  id="title"
                  value={newTask.title}
                  onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                  placeholder="What do you need to do?"
                  data-testid="input-task-title"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newTask.description || ""}
                  onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                  placeholder="Add more details..."
                  className="resize-none"
                  rows={3}
                  data-testid="input-task-description"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueTime">Due Date & Time *</Label>
                <Input
                  id="dueTime"
                  type="datetime-local"
                  value={format(newTask.dueTime, "yyyy-MM-dd'T'HH:mm")}
                  onChange={(e) => setNewTask({ ...newTask, dueTime: new Date(e.target.value) })}
                  data-testid="input-task-duetime"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAdding(false)}
                  data-testid="button-cancel-task"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending}
                  className="bg-gradient-to-r from-chart-1 to-chart-2"
                  data-testid="button-submit-task"
                >
                  {createMutation.isPending ? "Creating..." : "Create Task"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-12 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : tasks.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Bell className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No tasks yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create your first task to get started with reminders
            </p>
            <Button
              onClick={() => setIsAdding(true)}
              variant="outline"
              data-testid="button-create-first-task"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Task
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {incompleteTasks.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Bell className="w-5 h-5 text-chart-1" />
                Active Tasks ({incompleteTasks.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {incompleteTasks.map((task) => (
                  <Card
                    key={task.id}
                    className="hover-elevate transition-all duration-300 border-l-4 border-l-chart-1"
                    data-testid={`card-task-${task.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <CardTitle className="text-lg line-clamp-2">{task.title}</CardTitle>
                          {task.description && (
                            <CardDescription className="mt-2 line-clamp-2">
                              {task.description}
                            </CardDescription>
                          )}
                        </div>
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={(checked) =>
                            toggleMutation.mutate({ id: task.id, completed: !!checked })
                          }
                          className="mt-1"
                          data-testid={`checkbox-task-${task.id}`}
                        />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        <span>{format(new Date(task.dueTime), "PPp")}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate(task.id)}
                        className="w-full text-destructive hover:text-destructive"
                        data-testid={`button-delete-${task.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {completedTasks.length > 0 && (
            <div>
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Check className="w-5 h-5 text-chart-4" />
                Completed ({completedTasks.length})
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {completedTasks.map((task) => (
                  <Card
                    key={task.id}
                    className="opacity-75 hover:opacity-100 transition-opacity border-l-4 border-l-chart-4"
                    data-testid={`card-completed-${task.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <CardTitle className="text-lg line-through line-clamp-2">
                            {task.title}
                          </CardTitle>
                        </div>
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={(checked) =>
                            toggleMutation.mutate({ id: task.id, completed: !!checked })
                          }
                          className="mt-1"
                          data-testid={`checkbox-completed-${task.id}`}
                        />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteMutation.mutate(task.id)}
                        className="w-full text-destructive hover:text-destructive"
                        data-testid={`button-delete-completed-${task.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
