import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Brain, Code, Database, Server, Palette, Terminal, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Roadmap, LearningItem, InsertLearningItem } from "@shared/schema";

const TECHNOLOGY_ICONS = {
  HTML: Code,
  CSS: Palette,
  JavaScript: Terminal,
  React: Code,
  "Node.js": Server,
  Express: Server,
  MongoDB: Database,
  PostgreSQL: Database,
  TypeScript: Terminal,
  Python: Terminal,
  Django: Server,
  Flask: Server,
  MySQL: Database,
  Git: Terminal,
  Docker: Server,
  AWS: Server,
};

export default function Learning() {
  const { toast } = useToast();
  const [selectedRoadmap, setSelectedRoadmap] = useState<string | null>(null);
  const [newTech, setNewTech] = useState("");

  const { data: roadmaps = [] } = useQuery<Roadmap[]>({
    queryKey: ["/api/roadmaps"],
  });

  const { data: learningItems = [], isLoading } = useQuery<LearningItem[]>({
    queryKey: ["/api/learning-items", selectedRoadmap],
    enabled: !!selectedRoadmap,
  });

  const createMutation = useMutation({
    mutationFn: async (item: InsertLearningItem) => {
      return await apiRequest("POST", "/api/learning-items", item);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning-items", selectedRoadmap] });
      setNewTech("");
      toast({
        title: "Technology added!",
        description: "Keep learning and mark it complete when done.",
      });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: string; completed: boolean }) => {
      return await apiRequest("PATCH", `/api/learning-items/${id}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning-items", selectedRoadmap] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/learning-items/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/learning-items", selectedRoadmap] });
    },
  });

  const handleAddTech = () => {
    if (!selectedRoadmap) {
      toast({
        title: "Error",
        description: "Please select a roadmap first",
        variant: "destructive",
      });
      return;
    }
    if (!newTech.trim()) {
      toast({
        title: "Error",
        description: "Please enter a technology name",
        variant: "destructive",
      });
      return;
    }
    createMutation.mutate({
      roadmapId: selectedRoadmap,
      technology: newTech,
      completed: false,
      order: learningItems.length,
    });
  };

  const completedCount = learningItems.filter((item) => item.completed).length;
  const totalCount = learningItems.length;
  const percentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const activeRoadmaps = roadmaps.filter((r) => !r.completed);

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
          Learning Tracker
        </h1>
        <p className="text-muted-foreground mt-1">Track technologies and see your progress grow</p>
      </div>

      {activeRoadmaps.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Brain className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No active roadmaps</h3>
            <p className="text-muted-foreground text-center mb-4">
              Create a roadmap first to start tracking your learning
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card className="border-2 border-chart-1/20 shadow-lg">
            <CardHeader>
              <CardTitle>Select Roadmap</CardTitle>
              <CardDescription>Choose which learning path to track</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeRoadmaps.map((roadmap) => (
                  <Button
                    key={roadmap.id}
                    variant={selectedRoadmap === roadmap.id ? "default" : "outline"}
                    className={`justify-start h-auto py-4 ${
                      selectedRoadmap === roadmap.id
                        ? "bg-gradient-to-r from-chart-1 to-chart-2"
                        : ""
                    }`}
                    onClick={() => setSelectedRoadmap(roadmap.id)}
                    data-testid={`button-select-roadmap-${roadmap.id}`}
                  >
                    <Brain className="w-5 h-5 mr-2 flex-shrink-0" />
                    <span className="text-left">{roadmap.title}</span>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {selectedRoadmap && (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border-2 border-chart-2/20">
                  <CardHeader>
                    <CardTitle>Add Technology</CardTitle>
                    <CardDescription>What are you learning?</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="tech">Technology Name</Label>
                      <Input
                        id="tech"
                        value={newTech}
                        onChange={(e) => setNewTech(e.target.value)}
                        placeholder="e.g., HTML, CSS, React..."
                        onKeyDown={(e) => e.key === "Enter" && handleAddTech()}
                        data-testid="input-technology"
                      />
                    </div>
                    <Button
                      onClick={handleAddTech}
                      disabled={createMutation.isPending}
                      className="w-full bg-gradient-to-r from-chart-2 to-chart-3"
                      data-testid="button-add-technology"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {createMutation.isPending ? "Adding..." : "Add Technology"}
                    </Button>
                  </CardContent>
                </Card>

                <Card className="border-2 border-chart-1/20">
                  <CardHeader>
                    <CardTitle>Progress</CardTitle>
                    <CardDescription>Your learning journey</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center">
                      <div className="relative w-48 h-48">
                        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="40"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="8"
                            className="text-muted/20"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            r="40"
                            fill="none"
                            stroke="url(#learning-gradient)"
                            strokeWidth="8"
                            strokeLinecap="round"
                            strokeDasharray={`${percentage * 2.51} 251`}
                            className="transition-all duration-1000"
                          />
                          <defs>
                            <linearGradient id="learning-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" className="text-chart-1" stopColor="currentColor" />
                              <stop offset="50%" className="text-chart-2" stopColor="currentColor" />
                              <stop offset="100%" className="text-chart-3" stopColor="currentColor" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <div className="text-4xl font-bold bg-gradient-to-r from-chart-1 via-chart-2 to-chart-3 bg-clip-text text-transparent">
                            {percentage}%
                          </div>
                          <div className="text-sm text-muted-foreground">Complete</div>
                        </div>
                      </div>
                    </div>
                    <div className="mt-6 text-center">
                      <p className="text-sm text-muted-foreground">
                        {completedCount} of {totalCount} technologies mastered
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {isLoading ? (
                <Card className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-12 bg-muted rounded"></div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ) : learningItems.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <Code className="w-12 h-12 text-muted-foreground mb-3" />
                    <h3 className="font-semibold mb-2">No technologies added yet</h3>
                    <p className="text-sm text-muted-foreground">
                      Start adding technologies to track your learning
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Technologies</CardTitle>
                    <CardDescription>
                      Mark technologies as complete to increase your progress
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {learningItems.map((item) => {
                        const Icon =
                          TECHNOLOGY_ICONS[item.technology as keyof typeof TECHNOLOGY_ICONS] || Code;
                        return (
                          <div
                            key={item.id}
                            className={`flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                              item.completed
                                ? "bg-chart-4/10 border-chart-4/20"
                                : "bg-card hover-elevate border-card-border"
                            }`}
                            data-testid={`item-tech-${item.id}`}
                          >
                            <div className="flex items-center gap-3 flex-1">
                              <Checkbox
                                checked={item.completed}
                                onCheckedChange={(checked) =>
                                  toggleMutation.mutate({ id: item.id, completed: !!checked })
                                }
                                data-testid={`checkbox-tech-${item.id}`}
                              />
                              <Icon className="w-5 h-5 text-chart-1 flex-shrink-0" />
                              <span
                                className={`font-medium ${
                                  item.completed ? "line-through text-muted-foreground" : ""
                                }`}
                              >
                                {item.technology}
                              </span>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMutation.mutate(item.id)}
                              className="text-destructive hover:text-destructive"
                              data-testid={`button-delete-tech-${item.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}
