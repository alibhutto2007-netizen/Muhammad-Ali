# Comprehensive Design Guidelines: Gen Z Productivity Dashboard

## Design Approach

**Design System:** Custom productivity-focused system inspired by Linear's precision, Notion's flexibility, and modern Gen Z aesthetics (vibrant gradients, bold typography, smooth micro-interactions)

**Rationale:** This is a utility-focused, multi-feature productivity application requiring consistent patterns across task management, tracking, note-taking, and journaling interfaces. The design prioritizes information density, quick actions, and visual feedback while maintaining Gen Z appeal through vibrant color treatments and smooth transitions.

## Core Design Elements

### A. Typography

**Font Family:** Inter (primary) via Google Fonts CDN for all UI elements
- **Headings:** 
  - Page titles: text-3xl, font-bold (weight 700)
  - Section headers: text-xl, font-semibold (weight 600)
  - Card titles: text-lg, font-medium (weight 500)
- **Body Text:**
  - Primary content: text-base, font-normal (weight 400)
  - Helper text: text-sm, font-normal
  - Captions/timestamps: text-xs, font-medium

### B. Layout System

**Spacing Units:** Tailwind units of 2, 4, 6, and 8 as foundation (p-2, m-4, gap-6, h-8)
- Component padding: p-4 to p-6
- Section spacing: py-8 to py-12
- Card gaps: gap-4 to gap-6
- Button padding: px-6 py-3

**Container Structure:**
- Main app container: max-w-7xl mx-auto px-4
- Sidebar navigation: w-64 fixed height (if used) or top navigation bar
- Content area: Full-width with internal max-w-6xl for readability
- Card-based layouts with rounded-2xl corners

**Page Layouts:**
1. **Task Reminders:** Grid layout (grid-cols-1 md:grid-cols-2 lg:grid-cols-3) for task cards
2. **Sleep Tracker:** Single column centered form with large circular progress visualization
3. **Sticky Notes:** Absolute positioned draggable elements on canvas background
4. **Roadmaps:** Kanban-style columns or vertical timeline layout
5. **Learning Tracker:** Technology grid with checkboxes and prominent percentage display
6. **Daily Journal:** Centered text editor with feedback panel below

### C. Component Library

**Navigation:**
- Persistent sidebar (desktop) or bottom navigation bar (mobile)
- Icon + label combination using Heroicons via CDN
- Active state with gradient accent indicator
- Theme toggle button (sun/moon icon) in navigation header

**Cards:**
- Rounded-2xl with subtle shadow (shadow-lg in light, shadow-xl in dark)
- Padding: p-6
- Hover state: slight scale transform (scale-[1.02]) with transition duration-200
- Background: Semi-transparent with backdrop-blur for glass morphism effect

**Buttons:**
- Primary: Gradient background with rounded-lg, px-6 py-3
- Secondary: Outlined with gradient border
- Icon buttons: Circular (rounded-full) p-2 with icon size w-5 h-5
- Hover: Subtle glow effect and scale-[1.05] transform

**Form Inputs:**
- Rounded-lg borders with focus ring matching gradient theme
- Padding: px-4 py-3
- Labels: text-sm font-medium above input with mb-2
- Time pickers and date selectors with custom styling
- Textarea for notes/journal with min-h-32

**Progress Indicators:**
- Circular progress: Large donut chart (200-300px diameter) for sleep/learning percentages
- Linear progress: Gradient-filled bars with rounded-full ends, h-3
- Percentage text: Large (text-4xl font-bold) centered within circular indicators

**Sticky Notes:**
- Draggable cards with absolute positioning
- Different pastel gradient backgrounds per note
- Close button (×) in top-right corner
- Shadow-2xl for depth
- Min dimensions: w-48 h-48, max-w-xs

**Modals/Overlays:**
- Centered with backdrop blur (backdrop-blur-sm)
- Slide-in animation from bottom (translate-y)
- Close on backdrop click
- Z-index layering: z-50 for modals

**Data Display:**
- Technology checklist: Grid of checkbox items with icons
- Roadmap items: Timeline with connecting lines and milestone markers
- Task list: Strikethrough completed items with fade effect
- Feedback panels: Rounded boxes with gradient left border accent

### D. Animations & Transitions

**Global Transition Classes:**
- Default duration: transition-all duration-300 ease-in-out
- Quick actions: duration-150
- Page transitions: duration-500 with fade + slide

**Specific Animations:**
- Task completion: Fade out + shrink (scale-0 opacity-0)
- Progress updates: Smooth circular fill animation
- Theme toggle: Rotate sun/moon icon 180deg with color fade
- Sticky note drag: Cursor grab/grabbing, shadow increase during drag
- Notification toast: Slide in from top-right with bounce effect
- Percentage counter: Animated number count-up on completion

**No excessive animations** - maintain productivity focus with purposeful, smooth micro-interactions only

## Dark/Light Theme Implementation

**Theme Toggle:**
- Positioned in navigation header
- Instant theme switch with transition-colors duration-300 on all elements
- localStorage persistence: theme preference saved

**Color Application (Implementation Note):**
- Body background gradient in light theme
- Dark theme uses deep gradient backgrounds
- Cards maintain semi-transparency with backdrop-blur in both themes
- Text automatically adjusts contrast for accessibility
- Borders and shadows adapt to theme context

## Images

**No hero images required** - This is a dashboard application focused on functionality

**Icon Usage:**
- Heroicons via CDN (outline style for navigation, solid for actions)
- Task type icons (bell for reminders, moon for sleep, sticky note, roadmap, book)
- Size consistency: w-6 h-6 for navigation, w-5 h-5 for inline icons

## Additional Design Specifications

**Notification System:**
- Browser notification API for task reminders
- In-app toast notifications in top-right corner
- Gradient accent with icon and message
- Auto-dismiss after 5 seconds with slide-out animation

**Responsive Breakpoints:**
- Mobile: Single column layouts, bottom navigation
- Tablet (md:): Two-column grids where appropriate
- Desktop (lg:): Three-column grids, sidebar navigation

**Accessibility:**
- Focus states visible with gradient ring
- Keyboard navigation support for all interactive elements
- ARIA labels on icon-only buttons
- Sufficient contrast ratios in both themes
- Screen reader friendly progress announcements

**Interactive States:**
- Hover: Scale + shadow enhancement
- Active/Pressed: Slight scale down (scale-95)
- Disabled: Reduced opacity (opacity-50) with cursor-not-allowed
- Loading: Spinner with gradient animation

This design creates a cohesive, modern productivity ecosystem with Gen Z appeal through vibrant gradients, smooth interactions, and delightful micro-animations while maintaining the functional clarity needed for daily productivity tasks.