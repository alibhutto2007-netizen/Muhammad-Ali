import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Tasks with reminders
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  dueTime: timestamp("due_time").notNull(),
  completed: boolean("completed").notNull().default(false),
  notified: boolean("notified").notNull().default(false),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  notified: true,
}).extend({
  dueTime: z.union([z.date(), z.string().transform(str => new Date(str))]),
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Sleep records
export const sleepRecords = pgTable("sleep_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull().default(sql`now()`),
  hoursSlept: integer("hours_slept").notNull(),
  feedback: text("feedback"),
  sleepPercentage: integer("sleep_percentage").notNull(),
});

export const insertSleepRecordSchema = createInsertSchema(sleepRecords).omit({
  id: true,
  date: true,
  feedback: true,
  sleepPercentage: true,
});

export type InsertSleepRecord = z.infer<typeof insertSleepRecordSchema>;
export type SleepRecord = typeof sleepRecords.$inferSelect;

// Sticky notes
export const stickyNotes = pgTable("sticky_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  x: integer("x").notNull().default(100),
  y: integer("y").notNull().default(100),
  color: varchar("color", { length: 50 }).notNull().default("purple"),
});

export const insertStickyNoteSchema = createInsertSchema(stickyNotes).omit({
  id: true,
});

export type InsertStickyNote = z.infer<typeof insertStickyNoteSchema>;
export type StickyNote = typeof stickyNotes.$inferSelect;

// Roadmaps
export const roadmaps = pgTable("roadmaps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  completed: boolean("completed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertRoadmapSchema = createInsertSchema(roadmaps).omit({
  id: true,
  createdAt: true,
});

export type InsertRoadmap = z.infer<typeof insertRoadmapSchema>;
export type Roadmap = typeof roadmaps.$inferSelect;

// Learning items (technologies in a roadmap)
export const learningItems = pgTable("learning_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roadmapId: varchar("roadmap_id").notNull(),
  technology: text("technology").notNull(),
  completed: boolean("completed").notNull().default(false),
  order: integer("order").notNull().default(0),
});

export const insertLearningItemSchema = createInsertSchema(learningItems).omit({
  id: true,
});

export type InsertLearningItem = z.infer<typeof insertLearningItemSchema>;
export type LearningItem = typeof learningItems.$inferSelect;

// Daily journal entries
export const journalEntries = pgTable("journal_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull().default(sql`now()`),
  content: text("content").notNull(),
  feedback: text("feedback"),
  completionPercentage: integer("completion_percentage").notNull().default(0),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  date: true,
  feedback: true,
  completionPercentage: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;
