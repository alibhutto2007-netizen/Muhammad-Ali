# Productivity Hub - Personal Growth Companion

## Overview
A comprehensive productivity web application that helps users manage tasks, track sleep, organize notes, plan learning roadmaps, and journal daily progress. Features AI-powered feedback using Google Gemini for sleep analysis and learning journal insights.

## Purpose
- Help users stay on top of tasks with time-based reminders
- Monitor sleep quality and receive personalized recommendations
- Organize thoughts with draggable sticky notes
- Plan learning journeys with roadmaps
- Track technology learning progress with visual percentage indicators
- Reflect on daily learning with AI-powered feedback

## Current State
**MVP Features Implemented:**
- ✅ Schema and TypeScript types for all data models
- ✅ 6 main pages with beautiful UI:
  - Task Reminders (with due dates and completion tracking)
  - Sleep Tracker (with AI feedback and circular progress visualization)
  - Sticky Notes (draggable canvas with color options)
  - Roadmaps (create and manage learning paths)
  - Learning Tracker (technology checklist with progress percentage)
  - Daily Journal (with AI feedback and completion tracking)
- ✅ Sidebar navigation with icons
- ✅ Dark/Light theme toggle
- ✅ Responsive design with gradients and smooth transitions
- ✅ Design system with purple-pink-blue gradient theme

**In Progress:**
- Backend API implementation
- Data persistence
- AI integration with Gemini

## Recent Changes
- 2025-01-XX: Initial MVP implementation with all frontend components
- Added theme provider for dark/light mode switching
- Implemented sidebar navigation with all 6 features
- Created data schemas for tasks, sleep records, sticky notes, roadmaps, learning items, and journal entries

## User Preferences
- Gen Z aesthetic with vibrant gradients (purple, pink, blue)
- Smooth transitions and animations
- Dark/light theme support
- Clean, modern interface with good spacing
- AI-powered insights for sleep and learning

## Project Architecture

### Frontend (React + TypeScript)
- **Framework**: React with Wouter for routing
- **UI**: Shadcn components with Tailwind CSS
- **State**: TanStack Query for data fetching
- **Theme**: Custom theme provider with localStorage persistence
- **Components**:
  - `AppSidebar`: Navigation sidebar with theme toggle
  - `ThemeProvider`: Manages dark/light mode
  - Pages: Tasks, Sleep, Notes, Roadmaps, Learning, Journal

### Backend (Express + TypeScript)
- **Framework**: Express.js
- **Storage**: In-memory storage (MemStorage) for MVP
- **AI**: Google Gemini API for feedback generation
- **API Routes** (planned):
  - `/api/tasks` - Task CRUD operations
  - `/api/sleep` - Sleep tracking with AI feedback
  - `/api/notes` - Sticky notes management
  - `/api/roadmaps` - Roadmap CRUD
  - `/api/learning-items` - Technology tracking
  - `/api/journal` - Journal entries with AI feedback

### Data Models
1. **Tasks**: id, title, description, dueTime, completed, notified
2. **Sleep Records**: id, date, hoursSlept, feedback, sleepPercentage
3. **Sticky Notes**: id, content, x, y, color
4. **Roadmaps**: id, title, description, completed, createdAt
5. **Learning Items**: id, roadmapId, technology, completed, order
6. **Journal Entries**: id, date, content, feedback, completionPercentage

### Key Dependencies
- React & React DOM
- Wouter (routing)
- TanStack Query (data fetching)
- Tailwind CSS (styling)
- Shadcn UI (components)
- Lucide React (icons)
- Google Gemini AI (feedback generation)
- Express (backend)
- Drizzle ORM (schema definitions)
- Date-fns (date formatting)

## Design System
- **Colors**: Purple-pink-blue gradient theme
  - Primary: `271 91% 65%` (vibrant purple)
  - Chart colors for gradients
- **Typography**: Inter font family
- **Spacing**: Consistent padding and gaps
- **Borders**: Rounded with subtle shadows
- **Animations**: Smooth transitions on hover and interactions
- **Theme**: Dark and light modes with automatic color adjustments

## Environment Variables
- `GEMINI_API_KEY`: Google Gemini API key for AI feedback
- `SESSION_SECRET`: Session management (if needed)

## Browser Notifications
- Uses browser Notification API for task reminders
- User must grant permission on first use
- Notifications trigger when tasks are overdue

## AI Features
- **Sleep Feedback**: Analyzes sleep hours and provides personalized recommendations
- **Journal Feedback**: Evaluates daily learning entries and provides insights
- **Percentage Calculation**: AI determines completion/quality percentages

## Future Enhancements
- Database integration for data persistence across devices
- Recurring tasks and smart scheduling
- Sleep trend charts and analytics
- Collaborative roadmaps
- Export functionality (PDF/Markdown)
- Push notifications for mobile
- Calendar integration
- Pomodoro timer
- Habit tracking
