import {
  type Task,
  type InsertTask,
  type SleepRecord,
  type InsertSleepRecord,
  type StickyNote,
  type InsertStickyNote,
  type Roadmap,
  type InsertRoadmap,
  type LearningItem,
  type InsertLearningItem,
  type JournalEntry,
  type InsertJournalEntry,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Tasks
  getTasks(): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;

  // Sleep Records
  getSleepRecords(): Promise<SleepRecord[]>;
  createSleepRecord(record: InsertSleepRecord & { feedback: string; sleepPercentage: number }): Promise<SleepRecord>;

  // Sticky Notes
  getStickyNotes(): Promise<StickyNote[]>;
  createStickyNote(note: InsertStickyNote): Promise<StickyNote>;
  updateStickyNote(id: string, updates: Partial<StickyNote>): Promise<StickyNote | undefined>;
  deleteStickyNote(id: string): Promise<boolean>;

  // Roadmaps
  getRoadmaps(): Promise<Roadmap[]>;
  getRoadmap(id: string): Promise<Roadmap | undefined>;
  createRoadmap(roadmap: InsertRoadmap): Promise<Roadmap>;
  updateRoadmap(id: string, updates: Partial<Roadmap>): Promise<Roadmap | undefined>;
  deleteRoadmap(id: string): Promise<boolean>;

  // Learning Items
  getLearningItems(roadmapId?: string): Promise<LearningItem[]>;
  createLearningItem(item: InsertLearningItem): Promise<LearningItem>;
  updateLearningItem(id: string, updates: Partial<LearningItem>): Promise<LearningItem | undefined>;
  deleteLearningItem(id: string): Promise<boolean>;

  // Journal Entries
  getJournalEntries(): Promise<JournalEntry[]>;
  createJournalEntry(entry: InsertJournalEntry & { feedback: string; completionPercentage: number }): Promise<JournalEntry>;
}

export class MemStorage implements IStorage {
  private tasks: Map<string, Task>;
  private sleepRecords: Map<string, SleepRecord>;
  private stickyNotes: Map<string, StickyNote>;
  private roadmaps: Map<string, Roadmap>;
  private learningItems: Map<string, LearningItem>;
  private journalEntries: Map<string, JournalEntry>;

  constructor() {
    this.tasks = new Map();
    this.sleepRecords = new Map();
    this.stickyNotes = new Map();
    this.roadmaps = new Map();
    this.learningItems = new Map();
    this.journalEntries = new Map();
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const task: Task = {
      ...insertTask,
      id,
      notified: false,
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    const updated = { ...task, ...updates };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Sleep Records
  async getSleepRecords(): Promise<SleepRecord[]> {
    return Array.from(this.sleepRecords.values()).sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  async createSleepRecord(
    insertRecord: InsertSleepRecord & { feedback: string; sleepPercentage: number }
  ): Promise<SleepRecord> {
    const id = randomUUID();
    const record: SleepRecord = {
      id,
      date: new Date(),
      hoursSlept: insertRecord.hoursSlept,
      feedback: insertRecord.feedback,
      sleepPercentage: insertRecord.sleepPercentage,
    };
    this.sleepRecords.set(id, record);
    return record;
  }

  // Sticky Notes
  async getStickyNotes(): Promise<StickyNote[]> {
    return Array.from(this.stickyNotes.values());
  }

  async createStickyNote(insertNote: InsertStickyNote): Promise<StickyNote> {
    const id = randomUUID();
    const note: StickyNote = { ...insertNote, id };
    this.stickyNotes.set(id, note);
    return note;
  }

  async updateStickyNote(id: string, updates: Partial<StickyNote>): Promise<StickyNote | undefined> {
    const note = this.stickyNotes.get(id);
    if (!note) return undefined;
    const updated = { ...note, ...updates };
    this.stickyNotes.set(id, updated);
    return updated;
  }

  async deleteStickyNote(id: string): Promise<boolean> {
    return this.stickyNotes.delete(id);
  }

  // Roadmaps
  async getRoadmaps(): Promise<Roadmap[]> {
    return Array.from(this.roadmaps.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getRoadmap(id: string): Promise<Roadmap | undefined> {
    return this.roadmaps.get(id);
  }

  async createRoadmap(insertRoadmap: InsertRoadmap): Promise<Roadmap> {
    const id = randomUUID();
    const roadmap: Roadmap = {
      ...insertRoadmap,
      id,
      createdAt: new Date(),
    };
    this.roadmaps.set(id, roadmap);
    return roadmap;
  }

  async updateRoadmap(id: string, updates: Partial<Roadmap>): Promise<Roadmap | undefined> {
    const roadmap = this.roadmaps.get(id);
    if (!roadmap) return undefined;
    const updated = { ...roadmap, ...updates };
    this.roadmaps.set(id, updated);
    return updated;
  }

  async deleteRoadmap(id: string): Promise<boolean> {
    // Also delete associated learning items
    const items = Array.from(this.learningItems.values()).filter(
      (item) => item.roadmapId === id
    );
    items.forEach((item) => this.learningItems.delete(item.id));
    return this.roadmaps.delete(id);
  }

  // Learning Items
  async getLearningItems(roadmapId?: string): Promise<LearningItem[]> {
    const items = Array.from(this.learningItems.values());
    if (roadmapId) {
      return items.filter((item) => item.roadmapId === roadmapId).sort((a, b) => a.order - b.order);
    }
    return items;
  }

  async createLearningItem(insertItem: InsertLearningItem): Promise<LearningItem> {
    const id = randomUUID();
    const item: LearningItem = { ...insertItem, id };
    this.learningItems.set(id, item);
    return item;
  }

  async updateLearningItem(
    id: string,
    updates: Partial<LearningItem>
  ): Promise<LearningItem | undefined> {
    const item = this.learningItems.get(id);
    if (!item) return undefined;
    const updated = { ...item, ...updates };
    this.learningItems.set(id, updated);
    return updated;
  }

  async deleteLearningItem(id: string): Promise<boolean> {
    return this.learningItems.delete(id);
  }

  // Journal Entries
  async getJournalEntries(): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values()).sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }

  async createJournalEntry(
    insertEntry: InsertJournalEntry & { feedback: string; completionPercentage: number }
  ): Promise<JournalEntry> {
    const id = randomUUID();
    const entry: JournalEntry = {
      id,
      date: new Date(),
      content: insertEntry.content,
      feedback: insertEntry.feedback,
      completionPercentage: insertEntry.completionPercentage,
    };
    this.journalEntries.set(id, entry);
    return entry;
  }
}

export const storage = new MemStorage();
