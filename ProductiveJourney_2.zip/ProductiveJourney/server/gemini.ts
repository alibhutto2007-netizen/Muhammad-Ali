import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeSleepFeedback(hoursSlept: number): Promise<{
  feedback: string;
  sleepPercentage: number;
}> {
  try {
    const prompt = `You are a sleep health expert. A user slept for ${hoursSlept} hours. 
    
    Provide:
    1. Brief, encouraging feedback about their sleep (2-3 sentences)
    2. A sleep quality percentage (0-100) based on recommended 7-9 hours
    
    Respond with JSON in this exact format:
    {
      "feedback": "your encouraging feedback here",
      "sleepPercentage": number between 0-100
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            feedback: { type: "string" },
            sleepPercentage: { type: "number" },
          },
          required: ["feedback", "sleepPercentage"],
        },
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      const data = JSON.parse(rawJson);
      return {
        feedback: data.feedback,
        sleepPercentage: Math.min(100, Math.max(0, Math.round(data.sleepPercentage))),
      };
    }

    // Fallback
    const percentage = Math.min(100, Math.round((hoursSlept / 8) * 100));
    return {
      feedback: `You slept ${hoursSlept} hours. ${
        hoursSlept >= 7 && hoursSlept <= 9
          ? "Great job maintaining healthy sleep habits!"
          : hoursSlept < 7
          ? "Try to get more rest for optimal performance."
          : "You might want to adjust your sleep schedule."
      }`,
      sleepPercentage: percentage,
    };
  } catch (error) {
    console.error("Error generating sleep feedback:", error);
    const percentage = Math.min(100, Math.round((hoursSlept / 8) * 100));
    return {
      feedback: `You slept ${hoursSlept} hours. Keep tracking your sleep patterns!`,
      sleepPercentage: percentage,
    };
  }
}

export async function analyzeJournalEntry(content: string): Promise<{
  feedback: string;
  completionPercentage: number;
}> {
  try {
    const prompt = `You are a learning coach. A student wrote about their daily learning:

"${content}"

Provide:
1. Encouraging, specific feedback about their learning (3-4 sentences)
2. A completion/quality percentage (0-100) based on depth, effort, and progress shown

Respond with JSON in this exact format:
{
  "feedback": "your encouraging feedback here",
  "completionPercentage": number between 0-100
}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            feedback: { type: "string" },
            completionPercentage: { type: "number" },
          },
          required: ["feedback", "completionPercentage"],
        },
      },
      contents: prompt,
    });

    const rawJson = response.text;
    if (rawJson) {
      const data = JSON.parse(rawJson);
      return {
        feedback: data.feedback,
        completionPercentage: Math.min(100, Math.max(0, Math.round(data.completionPercentage))),
      };
    }

    // Fallback
    return {
      feedback: "Great work documenting your learning! Consistency is key to growth. Keep it up!",
      completionPercentage: 75,
    };
  } catch (error) {
    console.error("Error generating journal feedback:", error);
    return {
      feedback: "Thank you for sharing your learning journey. Keep building on this momentum!",
      completionPercentage: 70,
    };
  }
}
