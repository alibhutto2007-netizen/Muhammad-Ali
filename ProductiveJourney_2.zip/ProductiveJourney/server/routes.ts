import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeSleepFeedback, analyzeJournalEntry } from "./gemini";
import {
  insertTaskSchema,
  insertSleepRecordSchema,
  insertStickyNoteSchema,
  insertRoadmapSchema,
  insertLearningItemSchema,
  insertJournalEntrySchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Tasks
  app.get("/api/tasks", async (_req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const data = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(data);
      res.json(task);
    } catch (error) {
      res.status(400).json({ error: "Invalid task data" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const task = await storage.updateTask(id, req.body);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(400).json({ error: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteTask(id);
      if (!deleted) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  });

  // Sleep Records
  app.get("/api/sleep", async (_req, res) => {
    try {
      const records = await storage.getSleepRecords();
      res.json(records);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sleep records" });
    }
  });

  app.post("/api/sleep", async (req, res) => {
    try {
      const data = insertSleepRecordSchema.parse(req.body);
      
      // Get AI feedback
      const { feedback, sleepPercentage } = await analyzeSleepFeedback(data.hoursSlept);
      
      const record = await storage.createSleepRecord({
        ...data,
        feedback,
        sleepPercentage,
      });
      res.json(record);
    } catch (error) {
      console.error("Error creating sleep record:", error);
      res.status(400).json({ error: "Invalid sleep record data" });
    }
  });

  // Sticky Notes
  app.get("/api/notes", async (_req, res) => {
    try {
      const notes = await storage.getStickyNotes();
      res.json(notes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notes" });
    }
  });

  app.post("/api/notes", async (req, res) => {
    try {
      const data = insertStickyNoteSchema.parse(req.body);
      const note = await storage.createStickyNote(data);
      res.json(note);
    } catch (error) {
      res.status(400).json({ error: "Invalid note data" });
    }
  });

  app.patch("/api/notes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const note = await storage.updateStickyNote(id, req.body);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json(note);
    } catch (error) {
      res.status(400).json({ error: "Failed to update note" });
    }
  });

  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteStickyNote(id);
      if (!deleted) {
        return res.status(404).json({ error: "Note not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // Roadmaps
  app.get("/api/roadmaps", async (_req, res) => {
    try {
      const roadmaps = await storage.getRoadmaps();
      res.json(roadmaps);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch roadmaps" });
    }
  });

  app.post("/api/roadmaps", async (req, res) => {
    try {
      const data = insertRoadmapSchema.parse(req.body);
      const roadmap = await storage.createRoadmap(data);
      res.json(roadmap);
    } catch (error) {
      res.status(400).json({ error: "Invalid roadmap data" });
    }
  });

  app.patch("/api/roadmaps/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const roadmap = await storage.updateRoadmap(id, req.body);
      if (!roadmap) {
        return res.status(404).json({ error: "Roadmap not found" });
      }
      res.json(roadmap);
    } catch (error) {
      res.status(400).json({ error: "Failed to update roadmap" });
    }
  });

  app.delete("/api/roadmaps/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteRoadmap(id);
      if (!deleted) {
        return res.status(404).json({ error: "Roadmap not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete roadmap" });
    }
  });

  // Learning Items
  app.get("/api/learning-items/:roadmapId", async (req, res) => {
    try {
      const { roadmapId } = req.params;
      const items = await storage.getLearningItems(roadmapId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch learning items" });
    }
  });

  app.post("/api/learning-items", async (req, res) => {
    try {
      const data = insertLearningItemSchema.parse(req.body);
      const item = await storage.createLearningItem(data);
      res.json(item);
    } catch (error) {
      res.status(400).json({ error: "Invalid learning item data" });
    }
  });

  app.patch("/api/learning-items/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const item = await storage.updateLearningItem(id, req.body);
      if (!item) {
        return res.status(404).json({ error: "Learning item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(400).json({ error: "Failed to update learning item" });
    }
  });

  app.delete("/api/learning-items/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteLearningItem(id);
      if (!deleted) {
        return res.status(404).json({ error: "Learning item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete learning item" });
    }
  });

  // Journal Entries
  app.get("/api/journal", async (_req, res) => {
    try {
      const entries = await storage.getJournalEntries();
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch journal entries" });
    }
  });

  app.post("/api/journal", async (req, res) => {
    try {
      const data = insertJournalEntrySchema.parse(req.body);
      
      // Get AI feedback
      const { feedback, completionPercentage } = await analyzeJournalEntry(data.content);
      
      const entry = await storage.createJournalEntry({
        ...data,
        feedback,
        completionPercentage,
      });
      res.json(entry);
    } catch (error) {
      console.error("Error creating journal entry:", error);
      res.status(400).json({ error: "Invalid journal entry data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
